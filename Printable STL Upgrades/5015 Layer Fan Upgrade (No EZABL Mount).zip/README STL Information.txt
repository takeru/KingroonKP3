These were downloaded from the Kingroon Facebook Group here: https://www.facebook.com/groups/451554662353347/

The KingroonKP3_5015TH3DFanDuct.stl has a wider 5015 fan inlet to accomodate the TH3D 5015 24V Fan. https://www.th3dstudio.com/product/5015-high-speed-ball-bearing-fan-24v/